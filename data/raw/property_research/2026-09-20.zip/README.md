# Frozen individual-property evidence

553 named projects, including 20 EC-origin developments, and four separately assessed future land sites.

All source-row occurrences are preserved. New Sale, Sub Sale, Resale, tenure and EC/private groups remain separate. Missing price, rent or completion evidence is not filled with a regional estimate.

See `package_manifest.json` for every file hash. See `docs/individual-property-research.md` in the repository for the reproducible offline commands and evidence limits.
