# Regional supply, transport and buyer decisions

Research captured: 2026-09-20. Primary-source facts and analyst implications are labelled separately. This is context for the transaction analysis, not a complete status census of every project.

## Corrections that affect the purchase decision

- **North-South Corridor:** current LTA timetable is phased viaduct opening from **2029** and tunnel opening from **2031**. Earlier 2027/2029 dates are stale.
- **Jurong Region Line:** current LTA page lists **Stages 1 and 2 in 2028**, followed by Stage 3 in 2029.
- **The LakeGarden Residences:** Wing Tai's current portfolio labels **2027**; this is not actual TOP evidence. The prior 2026 expectation does not establish a 2026 move-in.
- **Future Canberra Drive EC:** the land tender is scheduled to close on **1 October 2026**, placing it in the ten-year-MOP tender cohort if it proceeds on that timetable. It is not currently launched housing stock.

## Tampines

Separate the mature Tampines/Simei resale decision from the future Tampines North package and the Tampines West integrated-project premium. The north has genuine future transport and amenity additions, but several large developments will create competing owner stock.

### TAM-01 — Tampines North rail is future provision

**Verified fact — under construction; expected 2030.** LTA expects Cross Island Line Phase 1 to complete by 2030; it serves Tampines. Tampines North also connects toward Punggol through the extension expected in 2032. [LTA — Cross Island Line](https://www.lta.gov.sg/content/ltagov/en/upcoming_projects/rail_expansion/cross_island_line.html)

**Buyer implication — inference.** For a near-term mover, compare the existing bus journey with the daily MRT journey at a completed resale alternative. A 2030 railway should not be treated as available on the buyer's 2026 move-in date.

Projects to compare or inspect: PARKTOWN RESIDENCE; AURELLE OF TAMPINES; TENET. Source as-of: LTA — Cross Island Line: 2026-08-04; retrieved 2026-09-20.

### TAM-02 — Parktown's facilities come with substantial future stock

**Verified fact — under development.** CapitaLand lists PARKTOWN Residence as under development, with 1,193 homes and a planned mall, bus interchange, community club, hawker centre and link to the future Tampines North MRT station. [CapitaLand — PARKTOWN Residence](https://www.capitaland.com/sg/en/stay/residential-development-listing/parktown-residence.html)

**Buyer implication — inference.** The integrated package can justify an own-stay convenience premium for the right household. It also creates many similar potential resale and rental substitutes; quantify the premium against completed owner transactions before paying it.

Projects to compare or inspect: PARKTOWN RESIDENCE. Source as-of: CapitaLand — PARKTOWN Residence: undated/current page; retrieved 2026-09-20.

### TAM-03 — Pinery competes through existing Tampines West rail

**Verified fact — launched project; planned integrated facilities.** Hoi Hup describes Pinery Residences as 588 homes, with planned underground pedestrian access to Tampines West MRT and an 11,300 sqm commercial mall. Its announcement gives a March 2026 preview. [Hoi Hup — Pinery Residences preview announcement](https://www.hoihup.com/)

**Buyer implication — inference.** Compare Pinery's station-and-mall package with nearby completed homes using the same floor-area cohort. An integrated-development premium is not automatically transferable to a nearby EC or a more distant Tampines project.

Projects to compare or inspect: PINERY RESIDENCES; RIVELLE TAMPINES. Source as-of: Hoi Hup — Pinery Residences preview announcement: 2026-03; retrieved 2026-09-20.

### TAM-04 — Aurelle is EC stock with an estimated completion date

**Verified fact — under development; anticipated TOP Q4 2027.** Sim Lian discloses 760 homes at Aurelle of Tampines and anticipates TOP in Q4 2027, subject to authority approval. [Sim Lian — Aurelle of Tampines](https://www.simlian.com.sg/property/aurelle-of-tampines/)

**Buyer implication — inference.** This is an EC purchase and holding-period decision, separate from unrestricted private resale. Do not count 760 homes as immediate open-market resale supply or infer legal move-in certainty from an anticipated TOP.

Projects to compare or inspect: AURELLE OF TAMPINES; TENET. Source as-of: Sim Lian — Aurelle of Tampines: undated/current page; retrieved 2026-09-20.

### TAM-05 — Rivelle broadens the family EC comparison

**Verified fact — EC development.** Sim Lian discloses 572 homes at Rivelle Tampines, with three- to five-bedroom layouts from 883 to 1,378 sqft. [Sim Lian — Rivelle Tampines](https://www.simlian.com.sg/property/rivelletampines/)

**Buyer implication — inference.** Use the actual area and layout, not bedroom labels alone, when comparing new ECs with older EC-origin resales. Similar bedrooms can mean different usable space and very different exit restrictions.

Projects to compare or inspect: RIVELLE TAMPINES; AURELLE OF TAMPINES; CITYLIFE@TAMPINES; THE TAMPINES TRILLIANT. Source as-of: Sim Lian — Rivelle Tampines: undated/current page; retrieved 2026-09-20.

### Which buyer decision this changes

- **Space-led buyers with a tight total-price cap.** Start with completed Tampines/Simei resales and older EC-origin homes in the required area band. Price renovation and the actual daily route before comparing them with smaller new homes at the same quantum.

- **Buyers paying for a new integrated package.** Compare PARKTOWN and Pinery separately: the former relies on future Tampines North rail, while the latter's proposition uses existing Tampines West rail. Require the present convenience and layout to justify the entry premium without assuming future capital growth.

- **Eligible long-horizon EC buyers.** Compare Aurelle/Rivelle/Tenet within EC rules first, then use mature EC-origin resales as the opportunity-cost comparison. Construction time plus the applicable MOP determines flexibility; an attractive PSF does not remove that constraint.

## Bedok

Bedok is several purchase markets: the established town centre, Tanah Merah, the reservoir and the coastal Bayshore/Siglap area. Existing rail access and generous older layouts can be bought today; the new coastal supply is also a competing choice, not solely a growth catalyst.

### BED-01 — Coastal TEL access is already delivered

**Verified fact — operating.** LTA records TEL Stage 4 opening on 23 June 2024, including Siglap and Bayshore stations. [LTA Annual Report 2023/24 — TEL4 opening](https://www.lta.gov.sg/content/dam/ltagov/who_we_are/statistics_and_publications/report/pdf/LTA_AR2324.pdf)

**Buyer implication — inference.** Treat TEL4 as an existing amenity when assessing current prices. An agent's description of its opening as a future catalyst would double-count a benefit already available.

Projects to compare or inspect: SEASIDE RESIDENCES; BAYSHORE PARK; THE BAYSHORE; COSTA DEL SOL. Source as-of: LTA Annual Report 2023/24 — TEL4 opening: 2024; retrieved 2026-09-20.

### BED-02 — Bayshore Drive has moved from tender to awarded land

**Verified fact — land awarded; no home-sales launch established here.** URA awarded Bayshore Drive to Gemini Residential and Gemini Trustee on 20 July 2026. The tender brief estimated 1,280 homes in a mixed-use development integrated with Bedok South MRT, a bus interchange and retail. [URA — Bayshore Drive land tender award](https://www.ura.gov.sg/news/media/pr26-55/) [URA — Bayshore Drive land tender launch](https://www.ura.gov.sg/news/media/pr26-23/)

**Buyer implication — inference.** A large integrated competitor can improve local amenities while competing for future buyers and tenants. Keep the 1,280 estimate in the supply watchlist; it is neither confirmed final stock nor an achieved home price.

Projects to compare or inspect: VELA BAY; BAYSHORE PARK; THE BAYSHORE; COSTA DEL SOL. Source as-of: URA — Bayshore Drive land tender award: 2026-07-20; URA — Bayshore Drive land tender launch: 2026-03-30; retrieved 2026-09-20.

### BED-03 — Fresh Bedok land award is a distinct future competitor

**Verified fact — land awarded; no home-sales launch established here.** URA awarded the 99-year New Upper Changi Road site to United Venture Development (Daisy) and CL Sapphire on 4 September 2026. [URA — New Upper Changi Road land tender award](https://www.ura.gov.sg/news/media/pr26-64/)

**Buyer implication — inference.** Revisit the buyer's alternatives once the developer publishes an actual unit mix and prices. The land award is evidence of future competition, not a defensible price floor for an existing flat.

Projects to compare or inspect: SKY EDEN@BEDOK; BEDOK RESIDENCES. Source as-of: URA — New Upper Changi Road land tender award: 2026-09-04; retrieved 2026-09-20.

### BED-04 — Vela Bay completion is a future estimate

**Verified fact — under development; expected completion 2031.** SingHaiyi lists Vela Bay at 1 and 3 Bayshore Walk as 515 private condominium homes on 99-year tenure, with expected completion in 2031. [SingHaiyi — Vela Bay project disclosure](https://www.singhaiyi.com/vela-bay.html)

**Buyer implication — inference.** For immediate occupancy, compare completed coastal alternatives. A buyer accepting a multi-year wait should explicitly price temporary accommodation and require an entry reason beyond the broad Bayshore transformation story.

Projects to compare or inspect: VELA BAY; SEASIDE RESIDENCES; COSTA DEL SOL. Source as-of: SingHaiyi — Vela Bay project disclosure: undated/current page; retrieved 2026-09-20.

### Which buyer decision this changes

- **Space-led family purchase.** Compare exact-size resale cohorts at Bedok Court, The Tanamera, East Meadows and Casa Merah before accepting a smaller new-launch unit for the same budget. Their condition, lease and station route matter more than the regional median.

- **Rail-and-amenity premium.** Keep town-centre and Tanah Merah comparisons local: Bedok Residences/Sky Eden and Sceneca/Grandeur Park are different catchments. Paying a premium requires a daily-use benefit; a Bedok-wide price average cannot establish it.

- **Coastal lifestyle or future supply buyer.** Compare existing TEL-served coastal stock with Vela Bay using usable area and total price. Track Bayshore Drive as future competition; do not require its eventual launch to lift the value of the chosen home.

## Canberra

Canberra already has rail service. The immediate decision is how much extra to pay for a new private home over owner-sale alternatives, with EC-origin stock placed in its correct eligibility cohort. The North-South Corridor now sits on a later timetable than older marketing material.

### CAN-01 — Canberra rail access is established

**Verified fact — operating.** LTA records Canberra MRT station opening on 2 November 2019. [LTA Annual Report 2019/20 — Canberra station opening](https://www.lta.gov.sg/content/dam/ltagov/who_we_are/statistics_and_publications/report/pdf/LTA_AR1920.pdf)

**Buyer implication — inference.** The station is present-day provision, not a new future catalyst. Compare each project's actual gate-to-station route and unit exposure rather than awarding the same convenience premium to every Canberra address.

Projects to compare or inspect: CANBERRA CRESCENT RESIDENCES; THE WATERGARDENS AT CANBERRA; THE COMMODORE; THE BROWNSTONE. Source as-of: LTA Annual Report 2019/20 — Canberra station opening: 2020; retrieved 2026-09-20.

### CAN-02 — North-South Corridor timing has shifted

**Verified fact — under construction; phased future openings.** LTA's current page expects the viaduct from Admiralty Road West to Lentor Avenue to open in phases from 2029 and the tunnel to ECP in phases from 2031. [LTA — North-South Corridor](https://www.lta.gov.sg/content/ltagov/en/upcoming_projects/road_commuter_facilities/north_south_corridor.html)

**Buyer implication — inference.** A short holding period may end before the full route is available. Underwrite today's commute and assess any nearby construction or elevated-road exposure; do not use old 2027/2029 dates to justify an entry premium.

Projects to compare or inspect: CANBERRA CRESCENT RESIDENCES; THE WATERGARDENS AT CANBERRA; THE COMMODORE. Source as-of: LTA — North-South Corridor: 2026-09-15; retrieved 2026-09-20.

### CAN-03 — Canberra Drive EC is a land-tender watchlist item

**Verified fact — tender scheduled to close after capture.** HDB launched the Canberra Drive EC site on 25 May 2026, with potential yield of about 185 homes and tender closing scheduled for 1 October 2026. [HDB — Canberra Drive EC land tender](https://www.hdb.gov.sg/hdb-pulse/news/2026/hdb-launches-tender-for-sale-site-at-canberra-drive)

**Buyer implication — inference.** Do not present the site as launched, priced, awarded or reservable. A household considering waiting for it must allow for land tender, construction and the new EC holding regime.

Projects to compare or inspect: CANBERRA DRIVE EC LAND SITE; PARC CANBERRA; PROVENCE RESIDENCE. Source as-of: HDB — Canberra Drive EC land tender: 2026-05-25; retrieved 2026-09-20.

### CAN-04 — EC eligibility cohorts change the exit comparison

**Verified fact — current policy; tender-date dependent.** HDB applies a ten-year MOP from TOP where the EC land tender closes on or after 8 May 2026; other projects retain five years. HDB distinguishes citizenship restrictions lasting to 15 years from TOP for the new cohort, versus 10 years for the older cohort. [HDB — Conditions after buying an EC](https://www.hdb.gov.sg/buying-a-flat/executive-condominiums/conditions-after-buying-an-ec) [HDB — Finding an EC](https://www.hdb.gov.sg/buying-a-flat/executive-condominiums/finding-an-ec)

**Buyer implication — inference.** The future Canberra Drive EC and existing EC-origin projects cannot share one resale-accessibility assumption. Project/block TOP dates and the buyer's eligibility must be established before an EC is an actionable alternative.

Projects to compare or inspect: CANBERRA DRIVE EC LAND SITE; THE BROWNSTONE; THE VISIONAIRE; PARC CANBERRA; PROVENCE RESIDENCE. Source as-of: HDB — Conditions after buying an EC: undated/current page; HDB — Finding an EC: undated/current page; retrieved 2026-09-20.

### Which buyer decision this changes

- **Private buyer comparing new versus owner sale.** Use Watergardens and The Commodore owner transactions in the same area band as the first test of Canberra Crescent's premium. A new home can fit the household; the future NSC alone does not establish an acceptable resale exit price.

- **Larger-home buyer considering an EC-origin resale.** Assess Brownstone, Visionaire and 1 Canberra in separate eligibility and tenure cohorts. Verify the applicable TOP anniversary; neither EC origin nor a current URA condominium label alone establishes who can buy.

- **Buyer willing to wait for a new EC.** Put Canberra Drive on a monitoring list rather than comparing a hypothetical launch price with current achieved transactions. The ten-year-MOP cohort creates a substantially longer commitment than an older EC resale.

## Lakeside/Jurong

Buy the specific combination of existing rail, lake access and usable space. The gardens are delivered; JRL and CRL are future additions with different station catchments. Lucerne Grand introduces an immediate marketing comparison before it supplies any achieved-price evidence.

### JUR-01 — Jurong Lake Gardens is delivered amenity

**Verified fact — opened.** NParks opened the rejuvenated Chinese and Japanese Gardens on 8 September 2024, completing the 90-hectare Jurong Lake Gardens development. [NParks — Completion of Jurong Lake Gardens](https://www.nparks.gov.sg/news/news-detail/nparks-completes-jurong-lake-gardens-with-opening-of-rejuvenated-chinese-and-japanese-gardens)

**Buyer implication — inference.** Garden access is an existing own-stay benefit. Distinguish direct access and real lake views from a broad Jurong address; do not count the 2024 opening again as future upside.

Projects to compare or inspect: THE LAKEGARDEN RESIDENCES; LAKEVILLE; LAKE GRANDE; LAKE LIFE. Source as-of: NParks — Completion of Jurong Lake Gardens: 2024-09-08; retrieved 2026-09-20.

### JUR-02 — JRL opening dates and catchments differ

**Verified fact — under construction.** LTA's current JRL page lists Stage 1 in 2028, Stage 2 in 2028 and Stage 3 in 2029. Interchanges are at Choa Chu Kang, Boon Lay and Jurong East. [LTA — Jurong Region Line](https://www.lta.gov.sg/content/ltagov/en/upcoming_projects/rail_expansion/jurong_region_line.html)

**Buyer implication — inference.** Check the relevant station and last-mile route. Existing Lakeside EWL access and a future JRL station are different propositions; do not apply a uniform uplift across the entire Jurong comparison.

Projects to compare or inspect: J GATEWAY; WESTMERE; SUMMERDALE; WESTWOOD RESIDENCES. Source as-of: LTA — Jurong Region Line: 2026-03-17; retrieved 2026-09-20.

### JUR-03 — CRL connection is a later horizon

**Verified fact — under construction; expected 2032.** LTA expects CRL Phase 2, which includes Jurong Lake District, to open in 2032; Phase 3 extending west is targeted for the late 2030s. [LTA — Cross Island Line](https://www.lta.gov.sg/content/ltagov/en/upcoming_projects/rail_expansion/cross_island_line.html)

**Buyer implication — inference.** A buyer planning to exit before 2032 should not need completed CRL service to make the purchase workable.

Projects to compare or inspect: J GATEWAY; THE LAKEGARDEN RESIDENCES; LAKE LIFE. Source as-of: LTA — Cross Island Line: 2026-08-04; retrieved 2026-09-20.

### JUR-04 — Lucerne Grand is preview evidence, not achieved pricing

**Verified fact — preview; booking scheduled after capture.** CDL announced 570 homes at Lucerne Grand, preview from 18 September 2026 and bookings from 3 October 2026. Advertised starting prices are S$1.498m for 624 sqft, S$1.988m for 883 sqft and S$2.788m for 1,152 sqft. [CDL — Lucerne Grand preview and booking announcement](https://www.cdl.com.sg/newsroom/cdl-presents-lucerne-grand-a-new-west-side-icon-directly-linked-to-lakeside-mrt-station)

**Buyer implication — inference.** This gives buyers a new station-linked alternative and creates direct developer competition. Keep starting prices separate from URA trades and verify the remaining layout/floor before treating a headline as an available home.

Projects to compare or inspect: LUCERNE GRAND; THE LAKEFRONT RESIDENCES; LAKEVILLE; LAKE GRANDE; THE LAKEGARDEN RESIDENCES. Source as-of: CDL — Lucerne Grand preview and booking announcement: 2026-09-16; retrieved 2026-09-20.

### JUR-05 — LakeGarden completion requires a current confirmation

**Verified fact — developer portfolio lists 2027; actual TOP not established.** Wing Tai's current portfolio lists The LakeGarden Residences as 306 homes with a 2027 year label. This differs from the earlier 2026 estimate used in the conversation. [Wing Tai — Residential portfolio](https://www.wingtaiasia.com/our-portfolio/residential/)

**Buyer implication — inference.** Do not advertise a 2026-ready move-in or confirmed TOP from old expected dates. Obtain the current TOP/key-collection evidence before budgeting a move, rental start or temporary housing period.

Projects to compare or inspect: THE LAKEGARDEN RESIDENCES. Source as-of: Wing Tai — Residential portfolio: undated/current page; retrieved 2026-09-20.

### Which buyer decision this changes

- **Lower-quantum larger-home purchase.** Use older Jurong and EC-origin resale cohorts such as Summerdale, Westmere and The Floravale to test the space available at the budget. Compare the household's actual commute and refurbishment bill against a smaller station-side home.

- **Compact-home buyer comparing new and resale.** Treat Lucerne's S$1.498m two-bedroom starting guide as a reason to compare Lakefront, Lakeville and Lake Grande at matching area, not as proof those resales should rise. A 624 sqft headline buys a different amount of space from many resale two-bedroom homes.

- **Lakeside lifestyle buyer with a longer horizon.** For LakeGarden and Lake Life, decide how much the particular unit's park access or view is worth separately from rail proximity. Require the purchase to work with current transport and a conservative completion assumption.

## Bukit Timah

Keep prime Bukit Timah, Beauty World and Upper Bukit Timah/Hume as distinct local choices. Tenure, age, floor area and station access vary widely. Turf City's transformation brings future services and competing supply over decades, not a guaranteed premium for every nearby owner.

### BT-01 — Hume station is already operating

**Verified fact — operating.** LTA records Hume station opening for passenger service on 28 February 2025. [LTA — Downtown Line](https://www.lta.gov.sg/content/ltagov/en/getting_around/public_transport/rail_network/downtown_line.html)

**Buyer implication — inference.** Assess the actual route from a shortlisted project to Hume. The opening is existing provision; 2026 purchase arithmetic should not count it again as a future catalyst.

Projects to compare or inspect: HILLVIEW REGENCY; HUME PARK I; HUME PARK II; HILLINGTON GREEN. Source as-of: LTA — Downtown Line: undated/current page; retrieved 2026-09-20.

### BT-02 — King Albert Park's interchange is future provision

**Verified fact — under construction; expected 2032.** LTA expects CRL Phase 2 in 2032, with a Downtown Line interchange at King Albert Park. [LTA — Cross Island Line](https://www.lta.gov.sg/content/ltagov/en/upcoming_projects/rail_expansion/cross_island_line.html)

**Buyer implication — inference.** Keep the existing DTL and the future interchange separate; confirm that the buyer's likely holding period and route benefit support paying any premium.

Projects to compare or inspect: MAPLE WOODS; THE BLOSSOMVALE; THE NEXUS; DUNEARN HOUSE. Source as-of: LTA — Cross Island Line: 2026-08-04; retrieved 2026-09-20.

### BT-03 — Turf City is long-horizon mixed housing supply

**Verified fact — long-term plan.** URA plans approximately 15,000–20,000 public and private homes at Bukit Timah Turf City, with full development described over roughly 20–30 years. [URA — Bukit Timah Turf City plans](https://www.ura.gov.sg/news/media/pr24-24/)

**Buyer implication — inference.** The plan can improve future amenities while adding many competing homes and years of works. It is neither an imminent private-condo completion count nor evidence that nearby entry prices must rise.

Projects to compare or inspect: DUNEARN HOUSE; ROYALGREEN; FOURTH AVENUE RESIDENCES; SIXTH AVENUE RESIDENCES. Source as-of: URA — Bukit Timah Turf City plans: 2024-05-23; retrieved 2026-09-20.

### BT-04 — Dunearn House is an actual launch within the new precinct

**Verified fact — launched; July weekend result is historical.** Frasers reported 212 of 380 Dunearn House homes sold during the first launch weekend in July 2026. [Frasers Property — Dunearn House launch weekend result](https://www.frasersproperty.com/content/frasersproperty/sg/press-releases/2026/07-jul/dunearn-house-sales.html)

**Buyer implication — inference.** The launch gives a real competing product to compare with completed nearby resales. July take-up is not September remaining inventory, and neither the launch average nor first-mover language sets an owner's exit value.

Projects to compare or inspect: DUNEARN HOUSE; ROYALGREEN; FOURTH AVENUE RESIDENCES. Source as-of: Frasers Property — Dunearn House launch weekend result: 2026-07-26; retrieved 2026-09-20.

### BT-05 — Reserve's TOP estimate differs from vacant possession

**Verified fact — under construction.** Far East lists The Reserve Residences under construction, with estimated TOP in Q1 2028 and expected vacant possession on 31 December 2028. [Far East Organization — Construction milestones](https://www.fareast.com/en/residential/construction-milestones)

**Buyer implication — inference.** Separate construction milestones from guaranteed occupancy when comparing a new integrated home with a completed alternative. Budget the timing gap and test whether the unit's layout and current alternatives justify the premium.

Projects to compare or inspect: THE RESERVE RESIDENCES; FORETT AT BUKIT TIMAH; THE LINQ @ BEAUTY WORLD. Source as-of: Far East Organization — Construction milestones: undated/current page; retrieved 2026-09-20.

### Which buyer decision this changes

- **Budget-constrained buyer seeking more area.** Search Upper Bukit Timah/Hume separately from prime central Bukit Timah. Match tenure and area before inferring a discount; an older large unit can have a lower PSF but a higher total renovation and ownership commitment.

- **Freehold versus newer leasehold choice.** For Forett and older freehold projects, compare real area and condition against newer leasehold integrated projects rather than calling all price differences a location premium. Tenure preference is personal; it does not establish near-term liquidity.

- **Prime new-launch purchase.** Compare Dunearn House with actual owner transactions around Sixth Avenue and with the household's timing. Turf City is an amenity-and-supply transformation lasting decades, so a profitable exit must not depend on the entire plan completing first.

## Evidence limits

The named projects identify comparisons to run, not a claim that every unit shares the same distance, view or exposure. No site visit or walking-route inspection was performed. School admissions, actual unit condition, contractual possession and buyer eligibility require their own checks. The supply estimates here are not aggregated: some are public plus private long-term plans, some are awarded land and others are already launched projects.

No appreciation rate is assigned to an infrastructure announcement. Use the transaction dossier to test entry premium, owner-sale liquidity and exit costs; use these facts to decide whether the household can wait and which alternatives it should price.

